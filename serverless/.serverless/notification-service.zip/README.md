# Five Talent Serverless AWS NODEJS Template

Serverless framework template for AWS NodeJS

## Quick Start

Create a new serverless project with this template by running:

```bash
serverless create --template-url https://github.com/FiveTalent/fts-aws-nodejs --path /path_to_awesome_service
```
